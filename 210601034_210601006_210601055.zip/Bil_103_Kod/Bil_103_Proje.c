#include <stdio.h>
#include <conio.h>
#include <ctype.h>
#include <stdlib.h>
int toplamMv = 0;
int mvKont[5] = { 0 };
void hataliDeger() {
	printf("\n\n\nHatali sayi girdiniz.\n\n\n");
}
int veriTemizle(int Oylar[6],int islemOylar[6],int islemOylar2[6]) {
	for (int i = 0; i < 6; i++) {
		Oylar[i] = 0;
		islemOylar[i] = 0;
		islemOylar2[i] = 0;
	}
	return Oylar[6];
	return islemOylar[6];
	return islemOylar[6];
}
int diziTopla() {
	for (int i = 0; i < 5; i++) {
		toplamMv += mvKont[i];
	}
	return toplamMv;
}
int main() {
	int genelOy[6][5] = { 0 };
	int genelOy2[6] = { 0 };
	int toplamOy = 0;
	int Oylar[6] = { 0 };
	int islemOylar[6] = { 0 };
	int islemOylar2[6] = { 0 };
	int mv[6] = { 0 };
	int mvGenel[6] = { 0 };
	char partiIsim[6] = { 'A','B','C','D','E','F' };
	char partiIsim2[6] = { 'A','B','C','D','E','F' };
	int oyToplami[6] = { 0 };
	int sehirKod[5] = { 1,2,3,4,5 };
	int x = 0;
	int partiBirincilik[6] = { 0 };
	int iktidar[6] = { 0 };
	printf("**********Secim Simulasyonuna Hosgeldiniz.**********\n");
	printf("Baslamak icin lutfen bir tusa tiklayiniz...\n");
	_getch();
	for (int l = 0; l < 5; l++) {
		printf("%d. Ilin Milletvekili Kontenjanini giriniz:", sehirKod[l]);
		scanf_s("%d", &mvKont[l]);
		diziTopla(toplamMv);
		if (mvKont[l] < 0) {
			hataliDeger();
			break;
		}
		printf("%d. Il icin;\n", sehirKod[l]);
		for (int i = 0; i < 6; i++) {
			printf("%c Partisinin aldigi oyu giriniz:", partiIsim[i]);
			scanf_s("%d", &Oylar[i]);
			if (Oylar[i] < 0) {
				hataliDeger();
				break;
			}
			islemOylar[i] = Oylar[i];
			islemOylar2[i] = Oylar[i];
			oyToplami[l] += Oylar[i];
			genelOy[i][l] = Oylar[i];
		}
		//İlimiz için kontenjanı ve parti oylarını kullanıcıdan aldık.Şimdi sıra işlem yapmakta.
		for (int k = 0; k < mvKont[l]; k++) {
			for (int i = 0; i < 7; i++) {
				for (int j = 1; j < 7 - i; j++) {
					if (islemOylar[j - 1] < islemOylar[j]) {
						int temp2 = islemOylar[j];
						islemOylar[j] = islemOylar[j - 1];
						islemOylar[j - 1] = temp2;
						int temp3 = mv[j];
						mv[j] = mv[j - 1];
						mv[j - 1] = temp3;
					}
				}
			}
			for (int m = 0; m < 6; m++) {
				if (islemOylar2[m] > islemOylar2[x]) {
					x = m;
				}
			}
			mvGenel[x] = mvGenel[x] + 1;
			islemOylar[0] = islemOylar[0] / 2;
			islemOylar2[x] = islemOylar[0];
			mv[0] += 1;
		}	//İşlem yapacağımız oyların kopyasından oluşan dizi ile Milletvekili atamalarımız gerçekleştiriyoruz.
		for (int i = 0; i < 7; i++) {
			for (int j = 1; j < 7 - i; j++) {
				if (Oylar[j - 1] < Oylar[j]) {
					int temp1 = Oylar[j];
					Oylar[j] = Oylar[j - 1];
					Oylar[j - 1] = temp1;
					int temp4 = partiIsim[j];
					partiIsim[j] = partiIsim[j - 1];
					partiIsim[j - 1] = temp4;
				}
			}
		}	//Sıralama için kullanacağımız Oylar dizisi ile birlikte Parti isimlerini de sıralıyoruz.
		for (int i = 0; i < 7; i++) {
			for (int j = 1; j < 7 - i; j++) {
				if (mv[j - 1] < mv[j]) {
					int temp3 = mv[j];
					mv[j] = mv[j - 1];
					mv[j - 1] = temp3;
				}
			}
		}
		//Tüm işlemlerden sonra , karışık olarak gelen Milletvekili dizisini de sıralıyoruz.
		printf("\n%d. Sehir icin Secim Sonuclari...\n\n", sehirKod[l]);
		printf("\t\tOy Sayisi\tMilletvekili Sayisi\tOy Yuzdesi\n");
		printf("\t\t----------\t-------------------\t-----------\n");
		for (int i = 0; i < 6; i++) {

			printf("%c Partisi\t    %d\t\t\t%d\t\t    %.2f\n", partiIsim[i], Oylar[i], mv[i], ((float)Oylar[i] / (float)oyToplami[l]) * 100);
		}
		printf("\nToplam Oy:%d\n", oyToplami[l]);//Daha sonra ülke geneli oyu bulmak üzere, her şehirde kullanılan toplam oyu bu Diziye kayıt ediyoruz.
		for (int i = 0; i < 6; i++) {
			genelOy2[i] = genelOy[i][0] + genelOy[i][1] + genelOy[i][2] + genelOy[i][3] + genelOy[i][4];
		}
		toplamOy += oyToplami[l];
		for (int i = 0; i < 6; i++) {
			partiIsim[i] = partiIsim2[i];
			Oylar[i] = 0;
			islemOylar[i] = 0;
			mv[i] = 0;
			iktidar[i] = mvGenel[i];
		}
		if (l < 4) {
			printf("\nBir sonraki sehir ile devam etmek icin lutfen bir tusa tiklayiniz...\n\n");
		}
		else {
			printf("\n\nTurkiye geneli sonuclari gormek icin lutfen bir tusa tiklayiniz...\n");
		}
		_getch();
		partiBirincilik[x] = partiBirincilik[x] + 1;
		//Türkiye geneli seçim sonuçları için gereken bilgileri topladık.
		veriTemizle(Oylar,islemOylar,islemOylar2);
	}
	int y = toplamMv / 3;
	for (int i = 0; i < 7; i++) {
		for (int j = 1; j < 7 - i; j++) {
			if (iktidar[j - 1] < iktidar[j]) {
				int temp = iktidar[j];
				iktidar[j] = iktidar[j - 1];
				iktidar[j - 1] = temp;
				int temp4 = partiIsim[j];
				partiIsim[j] = partiIsim[j - 1];
				partiIsim[j - 1] = temp4;
			}
		}
	}
	printf("\n\t\t----------Turkiye Geneli Secim Sonucu Tablosu----------\n\n\n");
	printf("\t\tOy Sayisi\tOy Yuzdesi\tMilletvekili Sayisi\tMilletvekili Yuzdesi\n");
	printf("\t\t---------\t----------\t-------------------\t---------------------\n");
	for (int i = 0; i < 6; i++) {
		printf("%c Partisi\t  %d\t\t   %.2f\t       %d\t\t    %.2f\n", partiIsim2[i], genelOy2[i], ((float)genelOy2[i] / (float)toplamOy) * 100, mvGenel[i], ((float)mvGenel[i] / (float)y) * 100);
	}
	printf("\nToplam Gecerli Oy Sayisi:%d\nToplam Milletvekili Kontenjani:%d\n\n", toplamOy, y);
	printf("Iktidar Partisi : %c Partisi\nAna Muhalefet Partisi: %c Partisi\n\n", partiIsim[0],partiIsim[1]);
	printf("Oy sayilarina gore;\n");
	for (int i = 0; i < 6; i++) {
		printf("%c Partisi %d Kez Birinci Oldu.\n",partiIsim2[i],partiBirincilik[i]);
	}
	return 0;
}
